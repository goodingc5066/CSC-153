﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerLibrary
{
    public class PreferredCustomer : Customer
    {
        // Fields
        private double _customerdiscount = 0.0;
        //Constructors
        public PreferredCustomer(string name, string address, string number, string customernumber, bool mailinglist, double customerpurchases)
        {
            Name = name;
            Address = address;
            Number = number;
            Customernumber = customernumber;
            Mailinglist = mailinglist;
            Customerpurchases = customerpurchases;
            Customerdiscount = _customerdiscount;

        }
        //Properties
        public double Customerpurchases { get; set; }
        public double Customerdiscount { get; set; }
        //Methods
        public double getDiscountPercent()
        {
            if (Customerpurchases >= 2000)
            {
                Customerdiscount = 100 * .10;

            }
            else if (Customerpurchases >= 1500 && Customerpurchases < 2000)
            {
                Customerdiscount = 100 * .07;
            }
            else if (Customerpurchases >= 1000 && Customerpurchases < 1500)
            {
                Customerdiscount = 100 * .06;
            }
            else if (Customerpurchases >= 500 && Customerpurchases < 1000)
            {
                Customerdiscount = 100 * .05;
            }
            else if (Customerpurchases < 500)
            {
                Customerdiscount = 0;
            }

            return Customerdiscount;
        }
    }
}
