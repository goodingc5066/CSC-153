﻿/**
* 2/3/2020
* CSC 153
* Chrystian Gooding
* This program is a menu to display some rooms,weapons,potions,treasure,items and mobs that will be in my game.
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdventure1_goodingc5066
{
    class Program
    {
        static void Main(string[] args)
        {
            //MainMenu
            //here are the arrays and list holding the names of variables in my game
            string[] Rooms = { "PlanetSurface", "CaveEntrance", "StarCraftBack", "StarCraftMiddle", "StarCraftFront" };
            string[] Weapons = { "RayGun", "PlasmaRifle", "EnergyBlade", "Grenade" };
            string[] Potions = { "FullRestore", "QuaterRestore" };
            string[] Treasure = { "Credits", "Titanium", "Radio Parts" };
            List<string> Items = new List<string>() { "Map", "DecoyGrenade", "LightAmmo", "HeaveyAmmo" };
            List<string> Mobs = new List<string>() { "Ghoul", "BrainEater", "FaceEater", "MediumWorm", "MimicQ" };
            bool exit = false;
            while (exit == false)
            {
                Console.WriteLine("1.Display Rooms");
                Console.WriteLine("2.Display Weapon");
                Console.WriteLine("3.Display Potion");
                Console.WriteLine("4.Display Treasure");
                Console.WriteLine("5.Display Items");
                Console.WriteLine("6.Display Mobs");
                Console.WriteLine("7.Exit");
                Console.WriteLine("Select an Option:");
                string input = Console.ReadLine();

                //if user inputs 1 displays array with rooms names
                if (input == "1")
                {
                    foreach (string value in Rooms)
                    {
                        Console.WriteLine(value);
                    }
                }
                //if user inputs 2 displays array with weapon names
                else if (input == "2")
                {
                    Array.Sort(Weapons);
                    foreach (string value in Weapons)
                    {
                        Console.WriteLine(value);
                    }
                }
                // if user inputs 3 displays array with potion names
                else if (input == "3")
                {
                    foreach (string value in Potions)
                    {
                        Console.WriteLine(value);
                    }
                }
                // is user inputs 4 displays array with treasure names
                else if (input == "4")
                {
                    foreach (string value in Treasure)
                    {
                        Console.WriteLine(value);
                    }
                }
                // if user inputs 5 displays  list with item names
                else if (input == "5")
                {
                    foreach (string value in Items)
                    {
                        Console.WriteLine(value);
                    }
                }
                // if user inputs 6 displays list with mob names
                else if (input == "6")
                {
                    foreach (string value in Mobs)
                    {
                        Console.WriteLine(value);
                    }
                    Console.ReadLine();
                }
                // if user inputs 7 exits program
                else if (input == "7")
                {
                    exit = true;
                    Console.WriteLine("You have selected to end the program goodbye");
                    Console.ReadLine();
                }
                // if user inputs anything but 1 to 7 displays error message
                else
                {
                    Console.WriteLine("Invalid Option Try Again:");
                }




            }
        }
    }
}
