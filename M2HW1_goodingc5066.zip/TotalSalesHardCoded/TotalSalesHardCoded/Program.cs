﻿/**
* 2/6/2020
* CSC 153
* Chrystian Gooding
* This program will display the given numbers as total sales
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TotalSalesHardCoded
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] saletotals = { 1245.67, 1189.55, 1098.72, 1456.88, 2109.34, 1987.55, 1872.36 };


            Console.WriteLine("The Total Sales are:");
            foreach(double value in saletotals)
            {
                Console.WriteLine(value);
            }
            Console.ReadLine();
        }
    }
}
