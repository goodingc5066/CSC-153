﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Text_Adventure_2
{
    class StandardMessages
    {
        public static void rooms()
        {
            Console.WriteLine("You are in Room:");
        }
        public static void Menu()
        {
            Console.WriteLine("1.Move North\n2.Move South\n3.Attack\n4.Exit\nSelect an Option:");
        }
        public static void DisplayPrompt()
        {
            Console.Write("You have gotten a hit point of :");
        }
        public static void exit()
        {
            Console.WriteLine("You have selected to end the program goodbye!!");
        }
        public static void invalidEntry()
        {
        Console.WriteLine("Invalid Option Try Again!!");
        }
    }

}
