﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Text_Adventure_2
{
    class roomSelect
    {
        public static int currentroom = 0;
        public static void North(string []Rooms)
        {

            if (currentroom == 4)
            {
                Console.WriteLine("You cannot go forward anymore!!");
            }
            else
            {
                currentroom = currentroom + 1;
                Console.WriteLine(Rooms[currentroom]);
            }
   
        }
        public static void South(string []Rooms)
        {
            if (currentroom == 0)
            {
                Console.WriteLine("You cannot go back anymore!!");
            }
            else
            {
                currentroom = currentroom - 1;
                Console.WriteLine(Rooms[currentroom]);
            }
        }
    }
}
