﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    
namespace ValueReturnLib
{

    public class RandGen
    {
        public static int random(int ouput)
        {
            //imports random generator
            Random random = new Random();
            //give the random generator a parameter of 21
           int output = random.Next(21);
            // returns a number between 1 and 20
            return output;
        }
    }
}
