﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DistanceLib
{
    public class Math
    {
        public static double FallingDistance (double seconds)
       
            {
            
            double gravity = 9.8;
            double squ;
            squ = (seconds * seconds);
            double distance;

            distance = (gravity *0.5)* squ;

            return distance;
            }
    }
}
