﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    { 
     
        static void Main(string[] args)
        {
            // ask user for the amount of seconds item has fallen
            Console.WriteLine("Please enter the seconds that object has fallen:");

            // turns user input into double
             double seconds = Convert.ToDouble(Console.ReadLine());

            // displays message for user before printing result
            StandardMessage.DisplayPrompt();

            // calls on method to return value and prints it for user
            Console.WriteLine(DistanceLib.Math.FallingDistance(seconds));

            // allows user to read the results
            Console.ReadLine();
        }
    }
}
