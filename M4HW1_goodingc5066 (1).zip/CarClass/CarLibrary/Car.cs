﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarLibrary
{
    public class Car
    {
        //Fields
        private string _year;
        private string _make;
        private int _speed;

        //constructors
        public Car ()
        {
            Year = "";
            Make = "";
            Speed = 0;


        }
        //custom
        public Car (string year, string make, int speed)
        {
            Year = year;
            Make = make;
            Speed = speed;
            
        }
        //full properties

        public string Year
        {
            get
            {
                return _year;
            }
            set
            {
                _year = value;

            }
        }

        public string Make
        {
            get
            {
                return _make;
            }
            set
            {
                _make = value;
            }
        }

        public int Speed
        {
            get
            {
                return _speed;
            }
            set
            {
                _speed = value;
            }
        }
    
        
        // Method for Car Accelerate
        public void Accelerate( )
        {
            if ( Speed >= 0)
            {
                Speed= Speed + 5;
                Console.WriteLine("Your current speed is " + Speed + " MPH");
            }

        }
        //Method for Car Brake
        public void Brake()
        {
            if (Speed == 0)
            {
                Console.WriteLine("You cannot brake anymore because the cars speed is 0 MPH");
            }
            else
            {
                Speed= Speed- 5;
                Console.WriteLine("You have decreased  your speed to " + Speed+ " MPH");
            }
        }
    }

}
