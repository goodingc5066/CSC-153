﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarLibrary
{
   public class StandardMessages
    {
        // Text in the menu
        public static void Menu()
        {
            Console.WriteLine("1. Create car\n2. Accelerate\n3. Brake\n4. Exit. \nSelect an Option:");
        }
        // Text for the exit statement
        public static void Exit()
        {
            Console.WriteLine("You have selected to end the program goodbye!!!");
            Console.WriteLine("-----------------------------------");
        }
        //text for invalid choice
        public static void InvalidChoice()
        {
            Console.WriteLine("Not a valid choice!!");
            Console.WriteLine("-----------------------------------");
        }
        //text for year input
        public static void Year()
        {
            Console.WriteLine("Enter a year:");
        }
        //text for make input
        public static void Make()
        {
            Console.WriteLine("Enter a make:");
        }
    }
}
