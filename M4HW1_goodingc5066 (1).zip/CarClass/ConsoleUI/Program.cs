﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**

* 3/20/2020

* CSC 153

* Chrystian Gooding

*This program will  ask the user for make and model and display the current speed of the car after being accelerated or braked.

*/

namespace ConsoleUI
{
    class Program
    { 
        static void Main(string[] args)
        {
            //a car object that displays the
            CarLibrary.Car thisCar = new CarLibrary.Car();
            // conditions for do while loop
            bool exit = false;
            //will do when the program starts
            do
            {
              //displays menu
              CarLibrary.StandardMessages.Menu();
                
                //switch statement that reads input from menu
                switch(Console.ReadLine())
                {
                    //if user  enters 1  stores the year and make of the car they have entered
                    case "1":
                        CarLibrary.Carbuild.BuildCar(thisCar);
                        break;
                        // if user enters 2 will increase the speed of the car by 10
                    case "2":
                        thisCar.Accelerate();
                        break;
                        // if user enters 3 will decrease the speed of the car by 10
                    case "3":
                        thisCar.Brake();
                        break;
                        // if user enters 4 will exit program
                    case "4":
                        exit = true;
                        CarLibrary.StandardMessages.Exit();
                        Console.ReadLine();
                        break;
                        // if user enters anything else will display error message
                    default:
                        CarLibrary.StandardMessages.InvalidChoice();
                        break;

                }
            }
            //will keep looping the program until exit equals true
            while (exit == false);
    }
    }
}
