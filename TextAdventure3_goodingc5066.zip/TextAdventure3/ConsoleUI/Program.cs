﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Player_library;
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {

            Player_library.Rooms[] Rooms = { new Player_library.Rooms("PlanetSurface", "", ""),
                                              new Player_library.Rooms("CaveEntrance", "" , ""),
                                             new Player_library.Rooms("StarCraftBack", "" , ""),
                                             new Player_library.Rooms("StarCraftMiddle", "" , ""),
                                             new Player_library.Rooms("StarCraftFront", "" , "") };// ARRAY FOR ROOMS
            string[] Weapons = { "RayGun", "PlasmaRifle", "EnergyBlade", "Grenade" };// ARRAYS FOR WEAPONS
            string[] Potions = { "FullRestore", "QuaterRestore" };// ARRAYS FOR POTIONS
            string[] Treasure = { "Credits", "Titanium", "Radio Parts" };// ARRAYS FOR TREASURE
            List<string> Items = new List<string>() { "Map", "DecoyGrenade", "LightAmmo", "HeaveyAmmo" };// LIST FOR ITEMS
            List<Player_library.Mobs> Mobs = new List<Player_library.Mobs> { new Mobs {MobName= "Ghoul" },
                                                                            new Mobs{MobName = "BrainEater" },
                                                                            new Mobs{ MobName ="FaceEater" },
                                                                            new Mobs{ MobName ="MediumWorm" },
                                                                            new Mobs { MobName ="Mimic" } };// LIST FOR MOBS
            // THis is the menu option given to the user
            bool exit = false;
            int subscript = 0;
            do

            {
                StandardMessages.Menu();
                Console.WriteLine($"You are currently in {Rooms[subscript].RoomName}");
                string input = Console.ReadLine();
                
                // if user enters 1 will run code
                if (input == "1")
                {
                   
                    if (subscript == 4)

                    {
                        Console.WriteLine("You cannot go forward anymore!!");
                    }
                    else
                    {
                        subscript++;
                        Console.WriteLine(Player_library.StandardMessages.rooms(Rooms[subscript]));
                    }
                   
                    


                    Console.WriteLine("__________________________");
                }
                // if user enters 2 will run code
                else if (input == "2")
                {
                    
                    if (subscript == 0)
                    {
                        Console.WriteLine("You cannot go backward anymore!!");
                    }
                    else
                    {
                        subscript--;
                        Console.WriteLine(Player_library.StandardMessages.rooms(Rooms[subscript]));

                    }
                   
                    Console.WriteLine("__________________________");


                }
                // if user enters 3 will run code
                else if (input == "3")
                {
                    // displays message to be shown before hitpoint
                    StandardMessages.DisplayPrompt();
                    // calls function to display the random hitpoint number
                    Console.WriteLine(Player_library.randgen.random(21));
                    Console.WriteLine("__________________________");

                }
                // if user enter 4 will exit code
                else if (input == "4")
                {

                    exit = true;
                    StandardMessages.exit();
                    Console.ReadLine();
                }
                // if user inputs something else display message and reshow code
                else
                {
                    StandardMessages.invalidEntry();
                    Console.WriteLine("__________________________");
                }
            } while (exit == false);
        }
    }
}
