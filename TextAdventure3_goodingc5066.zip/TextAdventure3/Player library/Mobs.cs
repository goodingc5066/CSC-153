﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Player_library
{
   public class Mobs
    {
        

        //Fields
        private string _mobname;
        private string _description;
        private int _health;
        private string _attributes;
      

        
         //constructors
         public Mobs()
         {
            MobName = "";
            Description = "";
            Health = 0;
            Attributes = "";

           
         }
         //custom
         public Mobs (string mobname, string description,string attributes, int health)
         {
             MobName = mobname;
             Description = description;
             Health = health;
            Attributes = attributes;

         }
         //fullproperties
         public string MobName
         {
             get
             {
                 return _mobname;
             }
             set
             {
                 _mobname = value;
             }
         }

         public string Description
         {
             get
             {
                 return _description;
             }
             set
             {
                 _description = value;
             }
         }
        public string Attributes
        {
            get
            {
                return _attributes;
            }
            set
            {
                _attributes = value;
            }
        }

        public int Health
         {
             get
             {
                 return _health;
             }
             set
             {
                 _health = value;
             }
         }
    
    }
}


