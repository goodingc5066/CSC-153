﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Player_library
{
    public class Player
    {
        //Fields
        private string _name;
        private string _password;
        private string _playerclass;
        private string _race;

        //constructors
        public Player()
        {
            Name = "admin";
            Password = "#Password";
            PlayerClass = "";
            Race = "";
        }
        //custom
        public Player (string name, string password, string playerclass, string race)
        {
            Name = name;
            Password = password;
            PlayerClass = playerclass;
            Race = race;
        }
        //fullproperties
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string Password
        {
            get
            {
                return _password;
            }
            set
            {
                _password = value;
            }
        }

        public string PlayerClass
        {
            get
            {
                return _playerclass;
            }
            set
            {
                _playerclass = value;
            }
        }

        public string Race
        {
            get
            {
                return _race;
            }
            set
            {
                _race = value;
            }
        }

    }
}
