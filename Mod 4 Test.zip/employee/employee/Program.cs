﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 2/10/2020
* CSC 153
* Chrystian Gooding
* This program will ask the user for employee name, phone number and ages then will display this infor and average the age os the employees.
*/
namespace employee
{
    class Program
    {
        static void Main(string[] args)
        {
            
           employeeLibrary.Employee workers = new employeeLibrary.Employee();

            List<employeeLibrary.Employee> employees2 = new List<employeeLibrary.Employee>();
            // Create input var for user input and sentry for loop
            string input;
            bool exit = false;
            // create constant Var
            const int SIZE = 5;

            //int nameIndex = 0, phoneIndex = 0;

            //string[] employeeNames = new string[SIZE];
            //string[] employeePhone = new string[SIZE];
            //List<int> employeeAge = new List<int>();
            do
            {
                // calling method to display menu
                Console.Write(employeeLibrary.StandardMessages.Menu());
                input = Console.ReadLine();


                //Switch to direct to proper process
                switch (input)
                {
                    case "1":
                        employeeLibrary.employeebuild.BuildWorkers(workers);
                       // Console.Write(employeeLibrary.StandardMessages.PromptForName());
                        //input = Console.ReadLine();
                       // EnterName(ref employeeNames, ref nameIndex, input);
                        break;
                    case "2":
                        DisplayEmpInfoToUser(Name, Phonenumber, Age);
                        //Console.Write(employeeLibrary.StandardMessages.PromptForNumber());
                        //input = Console.ReadLine();
                        //EnterPhone(ref employeePhone, ref phoneIndex, input);
                        break;
                    case "3":
                        Console.WriteLine(Age.Average());
                        Console.WriteLine("");

                        break;
                    case "4":
                        exit = true;
                        // calling method to display exit text
                        Console.Write(employeeLibrary.StandardMessages.Exit());
                        Console.WriteLine("");
                        Console.ReadLine();

                        break;
                    default:
                        // calling method to display invalid choice text
                        Console.Write(employeeLibrary.StandardMessages.DisplayNumberError());
                        Console.WriteLine("");
                        break;
                }
            } while (exit == false);
        }

        public static void EnterName(ref string[] name, ref int index, string input)
        {
            name[index] = input;
            index++;
            Console.WriteLine();
        }

        public static void EnterPhone(ref string[] phone, ref int index, string input)
        {
            phone[index] = input;
            index++;
            Console.WriteLine();

        }
        public static List<int> EnterAge(List<int> empAge, string input)
        {
            int number = 0;
            List<int> age = new List<int>();
            age = empAge;
            if (int.TryParse(input, out number))
            {
                age.Add(number);
                Console.WriteLine("");
            }
            else
            {
                Console.Write(employeeLibrary.StandardMessages.DisplayNumberError());
                Console.WriteLine("");
            }

            return age;


        }
        public static void DisplayEmpInfoToUser(string[] name, string[] phone, List<int> age)
        {
            for (int index = 0; index < age.Count; index++)
            {
                Console.WriteLine(employeeLibrary.StandardMessages.DisplayEmployee(name, phone, age, index));
                Console.WriteLine("");
            }
        }
    }
}
 
                       