﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employeeLibrary
{
   public class Employee
    {
        //Fields
        private string _name;
        private string _phonenumber;
        private int _age;
        //Constructors
        //Default
        public Employee()
        {
            Name = "";
            Phonenumber = "";
            Age = 0;
        }
        //custom
        public Employee (string name, string phonenumber, int age)
        {
            Name = name;
            Phonenumber = phonenumber;
            Age = age;
        }
        //full properties
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string Phonenumber
        {
            get
            {
                return _phonenumber;
            }
            set
            {
                _phonenumber= value;
            }
        }

        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                _age = value;
            }
        }
    }
}
