﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employeeLibrary
{
    public static class employeebuild
    {
        public static Employee BuildWorkers(Employee inputEmployee)
        {
            StandardMessages.PromptForName();
            inputEmployee.Name = Console.ReadLine();

            StandardMessages.PromptForNumber();
            inputEmployee.Phonenumber = Console.ReadLine();

            //StandardMessages.PromptForAge();
            //inputEmployee.Age = Console.ReadLine();



            return inputEmployee;

        }
    }
}
