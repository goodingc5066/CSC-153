﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employeeLibrary
{
    public class StandardMessages
    {
        public static string Menu()
        {
            return "1. Enter employee's information" +
                "\n2. Display employee information:\n3. Display average age of employees\n4. Exit\n-->";
        }

        public static string Exit()
        {
            return "You have selected to end the program\n";
        }

        public static string DisplayNumberError()
        {
            return "Not a Valid Number!";
        }

        public static string PromptForName()
        {
            return "Enter employee's name -->";
        }
        public static string PromptForNumber()
        {
            return "Enter employee's phone number -->";
        }
        public static string PromptForAge()
        {
            return "Enter employees age -->";
        }

        public static string DisplayEmployee(string[] name, string[] phone, List<int> age, int index)
        {
            return $"Employee Name - {name[index]}\n" +
                     $"Employee Phone - {phone[index]}\n" +
                     $"Employee Age - {age[index]}";
        }
    }
}
