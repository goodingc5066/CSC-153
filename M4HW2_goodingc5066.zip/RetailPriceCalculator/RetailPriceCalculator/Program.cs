﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 2/17/2020
* CSC 153
* Chrystian Gooding
* This program will ask the user for a price of an item and the mark up percent pass the variables to a method which calculates them passes them back and displays the items final price.
*/

namespace RetailPriceCalculator
{
    class Program
    {
        static void Main(string[] args)
            
        {
            // ask user for wholesale cost
            Console.WriteLine("What is the wholesale cost:");

            // accepts user input as string
             double wholesale = Convert.ToDouble(Console.ReadLine());

            // ask user for markup percent 
            Console.WriteLine("What is the markup percent:");
            // accepts user input as double
            double markup = Convert.ToDouble(Console.ReadLine());
            // displays message before results
            StandardMessage.DisplayPrompt();

            //returns method and prints results
            Console.WriteLine(RetailLib.Math.CalculateRetail(wholesale,markup));
            //allows user to read output
            Console.ReadLine();

        }

    }
}
