﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailPriceCalculator
{
    public static class StandardMessage
    {
        public static void DisplayPrompt()
        {
            Console.Write("The final retail cost is $");
        }
    }
}
