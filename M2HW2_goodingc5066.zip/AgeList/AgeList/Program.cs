﻿/**
* 2/6/2020
* CSC 153
* Chrystian Gooding
* This program will ask user for ages to put into a list then will display the ages entered into the list
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgeList
{
	class Program
	{
       
		static void Main(string[] args)

		{
            List<int> ages = new List<int>();
            bool exit = false;
			
			//MainMenu
			while (exit == false)

			{


				Console.WriteLine("1. Create an Age list");
				Console.WriteLine("2. Exit");
				Console.Write("Enter a choice: ");
				string input = Console.ReadLine();
                // is user enter 1 will ask for number of ages then ages themseleves then displays ages
				if (input == "1")
				{
					Console.WriteLine("How many ages will you enter:");
                   int TotalAges = Convert.ToInt32 (Console.ReadLine());
                    

                    

                    for (int index = 0; index < TotalAges; index++)
                    {
                        Console.WriteLine("Enter the Age:");
                        int ags = Convert.ToInt32(Console.ReadLine());
                        ages.Add(ags);
                    }

                    Console.WriteLine("Here are the entered ages:");
                    foreach (int value in ages)
					{
                        
						Console.WriteLine(value);
					}


				}
              

                
		        // if user enters 2 will end the program
				else if (input == "2")
				{
					exit = true;
					Console.WriteLine("You have selected to end the program bye.");
					Console.ReadLine();
				}

				else
				{
					Console.WriteLine("Invalid option please select 1 or 2");
					Console.ReadLine();

				}
			}



		}
	}
}
