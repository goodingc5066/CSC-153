﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees1
{
    class Methods
    {
        public static string EnterName()
        {
            int nameIndex = 0;
            string input;
            input = Console.ReadLine();
            const int SIZE = 5;
            string[] employeeNames = new string[SIZE];

            return employeeNames[nameIndex] = input; nameIndex++;
        }
       //// public static int EnterNumber(int employeenames)
        //{
         //   int output = 22;
         //   return output;
      ///  }
        //public static int EnterAge(int employeenames)
      //  {
      //      int output = 22;
        //    return output;
       // }
      //  public static int DisplayEmployee(int employeeNames,int index)
      ///  {
            
       //     return $"Employee Name - {employeeNames[index]}";
       // }
       // public static int DisplayAverageAge(int employeenames)
       // {
         //   int output = ;
        //    return output;
      //  }
    }
}
