﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/**
* 2/10/2020
* CSC 153
* Chrystian Gooding
* This program will ask the user for employee name, phone number and ages then will display this infor and average the age os the employees.
*/
namespace Employees1
{
    class Program1
    {


        static void Main(string[] args)

        {
            // Create input var for user input and sentry for loop
            string input;
            bool exit = false;
            // create constant Var
            const int SIZE = 5;

            int nameIndex = 0, phoneIndex = 0;

            string[] employeeNames = new string[SIZE];
            string[] employeePhone = new string[SIZE];
            List<int> employeeAge = new List<int>();


            do
            {
                // calling method to display menu
                Console.Write(EmployeeLibrary.StandardMessages.Menu());
                input = Console.ReadLine();


                //Switch to direct to proper process
                switch (input)
                {
                    case "1":
                        Console.Write(EmployeeLibrary.StandardMessages.choice1());
                        input = Console.ReadLine();
                        employeeNames[nameIndex] = input;
                        nameIndex++;
                        break;
                    case "2":
                        Console.Write(EmployeeLibrary.StandardMessages.choice2());
                        input = Console.ReadLine();
                        employeePhone[phoneIndex] = input;
                        phoneIndex++;
                        break;
                    case "3":
                        int number = 0;
                        Console.Write(EmployeeLibrary.StandardMessages.choice3());

                        input = Console.ReadLine();

                        if (int.TryParse(input, out number))
                        {
                            employeeAge.Add(number);
                            Console.WriteLine("");
                        }
                        else
                        {
                            Console.Write(EmployeeLibrary.StandardMessages.choice3num());
                            Console.WriteLine("");
                        }
                        break;
                    case "4":
                        for (int index = 0; index < employeeAge.Count; index++)
                        {
                            Console.WriteLine($"Employee Name - {employeeNames[index]}");
                            Console.WriteLine($"Employee Phone - {employeePhone[index]}");
                            Console.WriteLine($"Employee Age - {employeeAge[index]}");
                            Console.WriteLine("");
                        }
                        break;
                    case "5":
                        Console.WriteLine(employeeAge.Average());
                        Console.WriteLine("");
                        break;
                    case "6":
                        exit = true;
                        // calling method to display exit text
                        Console.Write(EmployeeLibrary.StandardMessages.exit());
                        Console.WriteLine("");
                        Console.ReadLine();
                        break;
                    default:
                        // calling method to display invalid choice text
                        Console.Write(EmployeeLibrary.StandardMessages.invalidchoice());
                        Console.WriteLine("");
                        break;
                }
            } while (exit == false);
        }
    }
}

        


