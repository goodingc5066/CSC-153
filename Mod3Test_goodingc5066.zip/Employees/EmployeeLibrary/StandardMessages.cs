﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class StandardMessages
    {
        public static string Menu()
        {
            return "1. Enter employee's name:\n2. Enter employee's phone number:\n3. Enter employee's age:" +
                "\n4. Display employee information:\n5. Display average age of employees\n6. Exit\n-->";
        }

        public static string exit()
        {
            return "You have selected to end the program\n";
        }

        public static string invalidchoice()
        {
            return "Not a Valid Choice!";
        }

        public static string choice1()
        {
            return "Enter employee's name -->";
        }
        public static string choice2()
        {
            return "Enter employee's phone number -->";
        }
        public static string choice3()
        {
            return "Enter employees age -->";
        }
        
        public static string choice3num()
        {
            return "Not a valid number!";
        }

    }

}
