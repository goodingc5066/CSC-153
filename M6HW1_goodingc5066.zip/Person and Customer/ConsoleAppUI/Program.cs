﻿/**
* 4/23/2020
* CSC 153
* Chrystian Gooding
* This program will inherit some properties from person class and use them along with other
* properties in customer class to display customer information
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerLibrary;

namespace ConsoleAppUI
{
    class Program
    {
        static void Main(string[] args)
        {

         //Customer info assigned to the properties in customer
            Customer firstcustomer = new Customer("Sandy","SwingStreet","9103569784","232",false );
        // Prints all of the information in order of being entered
            Console.WriteLine($"CustomerName is- {firstcustomer.Name}");
            Console.WriteLine($"CustomerAddress is- {firstcustomer.Address}");
            Console.WriteLine($"PhoneNumber is- {firstcustomer.Number}");
            Console.WriteLine($"CustomerNumber is- {firstcustomer.Customernumber}");
            Console.WriteLine($"MailingList is- {firstcustomer.Mailinglist}");
            Console.ReadLine();

        } 
    }
}
