﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerLibrary
{
    public class Customer : Person
    {
        // Fields

        //Constructors
        public Customer(string name, string address, string number, string customernumber, bool mailinglist) 
        {
            Name = name;
            Address = address;
            Number = number;
            Customernumber = customernumber;
            Mailinglist = mailinglist;
        }
        //Properties
        public string Customernumber { get; set; }
        public bool Mailinglist { get; set; }
    }
}
